const warDeckCards = [
	{ suit: "Spades", value: 2 }, //creating and nameing cards. placing value
	{ suit: "Spades", value: 3 },
	{ suit: "Spades", value: 4 },
	{ suit: "Spades", value: 5 },
	{ suit: "Spades", value: 6 },
	{ suit: "Spades", value: 7 },
	{ suit: "Spades", value: 8 },
	{ suit: "Spades", value: 9 },
	{ suit: "Spades", value: 10 },
	{ suit: "Spades", value: 11 },
	{ suit: "Spades", value: 12 },
	{ suit: "Spades", value: 13 },
	{ suit: "Spades", value: 14 },
	{ suit: "Diamonds", value: 2 },
	{ suit: "Diamonds", value: 3 },
	{ suit: "Diamonds", value: 4 },
	{ suit: "Diamonds", value: 5 },
	{ suit: "Diamonds", value: 6 },
	{ suit: "Diamonds", value: 7 },
	{ suit: "Diamonds", value: 8 },
	{ suit: "Diamonds", value: 9 },
	{ suit: "Diamonds", value: 10 },
	{ suit: "Diamonds", value: 11 },
	{ suit: "Diamonds", value: 12 },
	{ suit: "Diamonds", value: 13 },
	{ suit: "Diamonds", value: 14 },
	{ suit: "Hearts", value: 2 },
	{ suit: "Hearts", value: 3 },
	{ suit: "Hearts", value: 4 },
	{ suit: "Hearts", value: 5 },
	{ suit: "Hearts", value: 6 },
	{ suit: "Hearts", value: 7 },
	{ suit: "Hearts", value: 8 },
	{ suit: "Hearts", value: 9 },
	{ suit: "Hearts", value: 10 },
	{ suit: "Hearts", value: 11 },
	{ suit: "Hearts", value: 12 },
	{ suit: "Hearts", value: 13 },
	{ suit: "Hearts", value: 14 },
	{ suit: "Clubs", value: 2 },
	{ suit: "Clubs", value: 3 },
	{ suit: "Clubs", value: 4 },
	{ suit: "Clubs", value: 5 },
	{ suit: "Clubs", value: 6 },
	{ suit: "Clubs", value: 7 },
	{ suit: "Clubs", value: 8 },
	{ suit: "Clubs", value: 9 },
	{ suit: "Clubs", value: 10 },
	{ suit: "Clubs", value: 11 },
	{ suit: "Clubs", value: 12 },
	{ suit: "Clubs", value: 13 },
	{ suit: "Clubs", value: 14 }
];

function shuffle (array) { //https://www.frankmitchell.org/2015/01/fisher-yates/
  var i = 0
    , j = 0
    , temp = null

  for (i = array.length - 1; i > 0; i -= 1) {
    j = Math.floor(Math.random() * (i + 1))
    temp = array[i]
    array[i] = array[j]
    array[j] = temp
  }
};
shuffle(warDeckCards);
console.log(warDeckCards);

const player1Hand = warDeckCards.slice(0,26)
const player2Hand = warDeckCards.slice(26) 

console.log(player1Hand);
console.log(player2Hand);

console.log("Begin round one.")

const battleDeck1 = []
const battleDeck2 = []

var a = battleDeck1[0]
var b = battleDeck2[0]
// var c = battleDeck3[0]
// var a = battleDeck4[0]
// var b = battleDeck5[0]
// var c = battleDeck6[0]

function play(hand) {
k = player1Hand.pop() 
m = player2Hand.pop() 
battleDeck1.unshift(k);
battleDeck2.unshift(m);
console.log(battleDeck1);
console.log(battleDeck2);
} 

function battle(a,b) {
	if (a > b) { 
		battleDeck1.pop(a) && battleDeck2.pop(b) && player1Hand.unshift(a,b) && console.log("Player one wins the round.");
	} else if (a < b) { 
		battleDeck1.pop(a) && battleDeck2.pop(b) && player2Hand.unshift(a,b) && console.log("Player two wins the round.");
    } else {
  	    function war(statement) {
  	    	console.log("It's War!");
  	    }
  }
  console.log("End of Round one")
  }

if (player1Hand < 1) console.log("Player Two wins!")
if (player2Hand < 1) console.log("Player One wins!")



// function battle(a,b) {
// 	if (a > b) { 
// 		battleDeck1.pop(a) && battleDeck2.pop(b) && player1Hand.unshift(a,b) && console.log("Player one wins the round.");
// 	} else if (a < b) { 
// 		battleDeck1.pop(a) && battleDeck2.pop(b) && player2Hand.unshift(a,b) && console.log("Player two wins the round.");
//     } else {
//   	    function war(a,b,c) {
//   	    	player1Hand.pop(a,b,c) && battleDeck1.unshift(a,b,c) && player2Hand.pop(a,b,c) && battleDeck2.unshift(a,b,c) && console.log("It's War!");
//   	    }
//   }
//   } back-up battle function














